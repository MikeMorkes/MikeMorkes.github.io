// for escape key enthusiasts
window.document.onkeydown = function (e) 
{
    if (!e){
        e = event;
    }
    if (e.keyCode == 27){ 
        lightbox_close();
    }
}

var tempID = "";

// open function
function lightbox_open(id){
    window.scrollTo(0,0);
    document.getElementById(id).style.display='block';
    document.getElementById('fade').style.display='block';  
    tempID = id;
}

// close function
function lightbox_close(id){
    document.getElementById('fade').style.display='none';
    document.getElementById(tempID).style.display='none';
}
